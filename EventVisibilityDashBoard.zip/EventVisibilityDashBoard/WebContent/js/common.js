function showErrorAll(title, errors, w, h) {
	// console.log(content);

	defaultWidth = 600;
	defaultHeight = 400;

	if (undefined != w)
		defaultWidth = w;

	if (undefined != h)
		defaultHeight = h;

	$("#id_Error_Div").dialog({
		title : title,
		modal : true,
		closeOnEscape : true,
		autoOpen : false,
		show : "slow",
		width : defaultWidth,
		height : defaultHeight,
		hide : {
			effect : "explode",
			duration : 1000
		}
	});
	$("#id_Error_UL").html('');
	var errorLists = '';

	if ($.isArray(errors)) {
		$.each(errors,
			function(index, item) {
			  errorLists = errorLists + "<li class='label'>" + item+ "</li>";
		});
	} else
		errorLists = errorLists + "<li class='label'>" + errors + "</li>";
	$("#id_Error_UL").append(errorLists);
	$('#id_Error_Div').dialog('open');
}
