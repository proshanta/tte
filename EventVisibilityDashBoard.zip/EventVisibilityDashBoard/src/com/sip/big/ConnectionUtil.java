package com.sip.big;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

public class ConnectionUtil {
	
	Connection con = null;
	PreparedStatement pstmt = null;
	Statement stmt = null;
	ResultSet rs = null;
	Logger logger = Logger.getLogger("SIPAPP");
	
	
	/** 
	 * This method is used to create a connection object and send it back for further use.
	 * @return Connection object  
	 */
	public Connection getConnection(){
		Connection con = null;
		if(con == null){
			try{
				Context initContext = new InitialContext();
				Context envContext  = (Context)initContext.lookup("java:/comp/env");
				DataSource ds = (DataSource)envContext.lookup("jdbc/sip_foundation");
				con = ds.getConnection();
			}catch(NamingException e){
				logger.error("ConnectionUtil.getConnection: "+e.getMessage());
			}catch(SQLException sqlEx){
				logger.error("ConnectionUtil.getConnection: "+sqlEx.getMessage());
			}
		}
		return con;
	}
	
	/** 
	 * This method is used to return the results by executing the supplied SQL query
	 * @param sql SQL String
	 * @return ResultSet object  
	 */
	public ResultSet getResultSet(String sql) throws SQLException{
		if(con == null)
			con = getConnection();
		stmt = con.createStatement();
		return stmt.executeQuery(sql);
	}
	
	/** 
	 * This method is used to close the ResultSet object along with the statement and connection.
	 * @param rs The ResultSet object which is retrieved via getResultSet method
	 * @return Nothing  
	 */
	public void closeResult(ResultSet rs){
		// Close ResultSet
		try{
			if(rs != null){
				rs.close();
			}
		}catch(SQLException sqlEx){
			logger.error(sqlEx.getMessage());
		}
		
		//Close Statement
		try{
			if(stmt != null){
				stmt.close();
			}
		}catch(SQLException sqlEx){
			logger.error(sqlEx.getMessage());
		}
		// Close Prepared Statment
		try{
			if(pstmt != null){
				pstmt.close();
			}
		}catch(SQLException sqlEx){
			logger.error(sqlEx.getMessage());
		}
		//Close Connection
		try{
			if(con != null){
				con.close();
				con = null;
			}
		}catch(SQLException sqlEx){
			logger.error(sqlEx.getMessage());
		}
	}

	/** 
	 * This method is used to close all the DB objects received as a parameter
	 * @param conn The Connection object
	 * @param stmt The Statement object
	 * @param pstmt The PrepareStatement object
	 * @param rs The ResultSet object
	 */
	public void closeAll(Connection conn, Statement stmt, PreparedStatement pstmt, ResultSet rs){
		// Close ResultSet
		try{
			if(rs != null){
				rs.close();
			}
		}catch(SQLException sqlEx){
			logger.error(sqlEx.getMessage());
		}
		
		//Close Statement
		try{
			if(stmt != null){
				stmt.close();
			}
		}catch(SQLException sqlEx){
			logger.error(sqlEx.getMessage());
		}
		// Close Prepared Statment
		try{
			if(pstmt != null){
				pstmt.close();
			}
		}catch(SQLException sqlEx){
			logger.error(sqlEx.getMessage());
		}
		//Close Connection
		try{
			if(conn != null){
				conn.close();
			}
		}catch(SQLException sqlEx){
			logger.error(sqlEx.getMessage());
		}
		
	}
}
