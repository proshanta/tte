package com.sip.big;

import java.util.List;

public class EventDetails {

	public String containerNo;
	public String trackingId;
	public String containerType;
	public String bolNumber;
	public String cargoType;
	public String VGM;
	public String cargoWeight;
	public String eventId;
	public String eventName;
	public String eventDesc;
	public String documentType;
	public String eventDataType;
	public String eventData;
	public String locationType;
	public String location;
	public String eventDateTime;
	public String eventReportedTime;
	public String soeId;
	public String soeName;
	public String originatorName;
	public String originatorId;
	public String toCountry;
	public String fromCountry;
	public String imoNumber;
	public String voyageNumber;
	public String eventDec;
	public List<String> routeList;
	public List<String> documentList;
	public String documentURI;
	public String GPSCoordinates;
	public String portId;
    public String countryName;
    public String portDtls;
    
	public String getPortId() {
		return portId;
	}

	public void setPortId(String portId) {
		this.portId = portId;
	}

	public String getGPSCoordinates() {
		return GPSCoordinates;
	}

	public void setGPSCoordinates(String gPSCoordinates) {
		GPSCoordinates = gPSCoordinates;
	}

	public String getEventData() {
		return eventData;
	}

	public void setEventData(String eventData) {
		this.eventData = eventData;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getEventDesc() {
		return eventDesc;
	}

	public void setEventDesc(String eventDesc) {
		this.eventDesc = eventDesc;
	}

	public String getDocumentURI() {
		return documentURI;
	}

	public void setDocumentURI(String documentURI) {
		this.documentURI = documentURI;
	}

	public String getEventDec() {
		return eventDec;
	}

	public void setEventDec(String eventDec) {
		this.eventDec = eventDec;
	}

	public String getContainerNo() {
		return containerNo;
	}

	public void setContainerNo(String containerNo) {
		this.containerNo = containerNo;
	}

	public String getTrackingId() {
		return trackingId;
	}

	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}

	public String getContainerType() {
		return containerType;
	}

	public void setContainerType(String containerType) {
		this.containerType = containerType;
	}

	public String getBolNumber() {
		return bolNumber;
	}

	public void setBolNumber(String bolNumber) {
		this.bolNumber = bolNumber;
	}

	public String getCargoType() {
		return cargoType;
	}

	public void setCargoType(String cargoType) {
		this.cargoType = cargoType;
	}

	public String getVGM() {
		return VGM;
	}

	public void setVGM(String vGM) {
		VGM = vGM;
	}

	public String getCargoWeight() {
		return cargoWeight;
	}

	public void setCargoWeight(String cargoWeight) {
		this.cargoWeight = cargoWeight;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getEventDataType() {
		return eventDataType;
	}

	public void setEventDataType(String eventDataType) {
		this.eventDataType = eventDataType;
	}

	public String getLocationType() {
		return locationType;
	}

	public void setLocationType(String locationType) {
		this.locationType = locationType;
	}

	public String getEventDateTime() {
		return eventDateTime;
	}

	public void setEventDateTime(String eventDateTime) {
		this.eventDateTime = eventDateTime;
	}

	public String getEventReportedTime() {
		return eventReportedTime;
	}

	public void setEventReportedTime(String eventReportedTime) {
		this.eventReportedTime = eventReportedTime;
	}

	public String getSoeId() {
		return soeId;
	}

	public void setSoeId(String soeId) {
		this.soeId = soeId;
	}

	public String getSoeName() {
		return soeName;
	}

	public void setSoeName(String soeName) {
		this.soeName = soeName;
	}

	public String getOriginatorName() {
		return originatorName;
	}

	public void setOriginatorName(String originatorName) {
		this.originatorName = originatorName;
	}

	public String getOriginatorId() {
		return originatorId;
	}

	public void setOriginatorId(String originatorId) {
		this.originatorId = originatorId;
	}

	public String getToCountry() {
		return toCountry;
	}

	public void setToCountry(String toCountry) {
		this.toCountry = toCountry;
	}

	public String getFromCountry() {
		return fromCountry;
	}

	public void setFromCountry(String fromCountry) {
		this.fromCountry = fromCountry;
	}

	public String getImoNumber() {
		return imoNumber;
	}

	public void setImoNumber(String imoNumber) {
		this.imoNumber = imoNumber;
	}

	public String getVoyageNumber() {
		return voyageNumber;
	}

	public void setVoyageNumber(String voyageNumber) {
		this.voyageNumber = voyageNumber;
	}

	public List<String> getRouteList() {
		return routeList;
	}

	public void setRouteList(List<String> routeList) {
		this.routeList = routeList;
	}

	public List<String> getDocumentList() {
		return documentList;
	}

	public void setDocumentList(List<String> documentList) {
		this.documentList = documentList;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public String getPortDtls() {
		return portDtls;
	}

	public void setPortDtls(String portDtls) {
		this.portDtls = portDtls;
	}

}
