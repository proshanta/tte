package com.sip.big;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts2.interceptor.ServletRequestAware;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.log4j.Logger;

public class Login extends ActionSupport implements ServletRequestAware {

	private static final long serialVersionUID = 1L;
	public LoginContract loginContract = new LoginContract();
	private String userName;
	private String password;
	private static Logger logger = Logger.getLogger("SIPAPP");

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String loginauth() {

		logger.info("Entering loginauth() of Login in EVD");
		ConnectionUtil conUtil = new ConnectionUtil();
		PreparedStatement preparedStatement = null;
		String returnValue = ERROR;
		ResultSet userDetailrs = null;
		String userNameDB = null;
		Connection connection = conUtil.getConnection();
		String passwordDB = null;
		try {
			String sql = "select a.UserName,a.password from sip_foundation.login a where a.UserName=" + "'" + this.getUserName() + "'"
					+ " and a.password=" + "'" + this.getPassword() + "'";

			preparedStatement = connection.prepareStatement(sql);
			userDetailrs = preparedStatement.executeQuery();
			while (userDetailrs.next()) {
				userNameDB = userDetailrs.getString("a.UserName");
				passwordDB = userDetailrs.getString("a.Password");
				loginContract.setUserName(userNameDB);
				loginContract.setPassword(passwordDB);
			}

			if (null != this.getUserName() && null != this.getPassword()
					&& null != userNameDB && null != passwordDB) {
				if (userNameDB.equals(this.getUserName()) && passwordDB.equals(this.getPassword())) {
					returnValue = SUCCESS;
				} else {
					addActionError("Invalid userid or password.");
				}
			}
			else {
				addActionError("Invalid userid or password.");
			}
		} catch (SQLException e) {
			logger.error("Exception caught in loginauth() of Login in EVD " + e.getMessage());
		} finally {
			conUtil.closeAll(connection, null, preparedStatement, userDetailrs);
		}

		logger.info("Exiting loginauth() of Login in EVD");

		return returnValue;
	}

	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		// TODO Auto-generated method stub
	}

}
