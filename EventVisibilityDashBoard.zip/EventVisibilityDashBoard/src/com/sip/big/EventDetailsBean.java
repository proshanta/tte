package com.sip.big;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class EventDetailsBean {

	public String ShipmentEventId;
	public String SOEID;
	public String EventId;
	public String Data;
	public String TrackingId;
	public String OriginatorId;
	public String CreationDateTime;
	public String MailSentCountry;
	public String ContainerNo;
	public String PubDateTime;
	public String MailSentPort;
	public String CargoType;
	public String GPSCoordinates;
	public String Trackflag;
	public String location;
	public String CountryId;
	public String PortId;
	public String OriginatorName;
	public String EventDataType;
	public String DocumentType;
	public String DocumentHashKey;
	public String DocumentPublicKey;
	public String DelegationId;
	public String DocumentURI;
	public String LocationType;
	public String SHIPMENTEVENTID;
	public String locationOrder;
	public String event_countryid;
	public String Id;
	public String EVENT_PORTID;
	public String ShipmentEventID;
	public String bolNumber;
	public String etdOrEtaPort;
	public String etdOrEta;
	public String etdOrEtaDate;
	public HashSet<String> containerNoList = new HashSet<String>();
	public ArrayList<EventData> eventList = new ArrayList<EventData>();
	public LinkedHashMap<String, ArrayList<EventData>> portwiseEventData = new LinkedHashMap<String, ArrayList<EventData>>();
	public List<String> estimatedDepTime = new ArrayList<String>();
	public List<String> estimatedArrTime = new ArrayList<String>();
	public List<String> contDischargeFromPortList = new ArrayList<String>();
	
	public String getEtdOrEtaPort() {
		return etdOrEtaPort;
	}

	public void setEtdOrEtaPort(String etdOrEtaPort) {
		this.etdOrEtaPort = etdOrEtaPort;
	}

	public String getEtdOrEta() {
		return etdOrEta;
	}

	public void setEtdOrEta(String etdOrEta) {
		this.etdOrEta = etdOrEta;
	}
	
	public String getEtdOrEtaDate() {
		return etdOrEtaDate;
	}

	public void setEtdOrEtaDate(String etdOrEtaDate) {
		this.etdOrEtaDate = etdOrEtaDate;
	}

	public List<String> getContDischargeFromPortList() {
		return contDischargeFromPortList;
	}

	public void setContDischargeFromPortList(
			List<String> contDischargeFromPortList) {
		this.contDischargeFromPortList = contDischargeFromPortList;
	}

	public String fromCountry;
	public String toCountry;
	public String inTrackingId;
	public String inContainerNo;
	public String inBolNo;
	public String inFromDate;
	public String inToDate;
	public String vgm;
	public String containerTypeSize;
	public String dangerousGoods;

	public String getBolNumber() {
		return bolNumber;
	}

	public void setBolNumber(String bolNumber) {
		this.bolNumber = bolNumber;
	}

	public String getVgm() {
		return vgm;
	}

	public void setVgm(String vgm) {
		this.vgm = vgm;
	}

	public String getDangerousGoods() {
		return dangerousGoods;
	}

	public void setDangerousGoods(String dangerousGoods) {
		this.dangerousGoods = dangerousGoods;
	}

	public String getContainerTypeSize() {
		return containerTypeSize;
	}

	public void setContainerTypeSize(String containerTypeSize) {
		this.containerTypeSize = containerTypeSize;
	}

	public List<String> getEstimatedDepTime() {
		return estimatedDepTime;
	}

	public void setEstimatedDepTime(List<String> estimatedDepTime) {
		this.estimatedDepTime = estimatedDepTime;
	}

	public List<String> getEstimatedArrTime() {
		return estimatedArrTime;
	}

	public void setEstimatedArrTime(List<String> estimatedArrTime) {
		this.estimatedArrTime = estimatedArrTime;
	}

	TreeMap<String, Map<String, String>> transportationMap;

	public TreeMap<String, Map<String, String>> getTransportationMap() {
		return transportationMap;
	}

	public void setTransportationMap(
			TreeMap<String, Map<String, String>> transportationMap) {
		this.transportationMap = transportationMap;
	}

	public String getInTrackingId() {
		return inTrackingId;
	}

	public void setInTrackingId(String inTrackingId) {
		this.inTrackingId = inTrackingId;
	}

	public String getInContainerNo() {
		return inContainerNo;
	}

	public void setInContainerNo(String inContainerNo) {
		this.inContainerNo = inContainerNo;
	}

	public String getInBolNo() {
		return inBolNo;
	}

	public void setInBolNo(String inBolNo) {
		this.inBolNo = inBolNo;
	}

	public String getInFromDate() {
		return inFromDate;
	}

	public void setInFromDate(String inFromDate) {
		this.inFromDate = inFromDate;
	}

	public String getInToDate() {
		return inToDate;
	}

	public void setInToDate(String inToDate) {
		this.inToDate = inToDate;
	}

	public String getFromCountry() {
		return fromCountry;
	}

	public void setFromCountry(String fromCountry) {
		this.fromCountry = fromCountry;
	}

	public String getToCountry() {
		return toCountry;
	}

	public void setToCountry(String toCountry) {
		this.toCountry = toCountry;
	}

	public ArrayList<String> getRoute() {
		return route;
	}

	public void setRoute(ArrayList<String> route) {
		this.route = route;
	}

	public ArrayList<String> route;

	public HashSet<String> getContainerNoList() {
		return containerNoList;
	}

	public void setContainerNoList(HashSet<String> containerNoList) {
		this.containerNoList = containerNoList;
	}

	public ArrayList<EventData> getEventList() {
		return eventList;
	}

	public void setEventList(ArrayList<EventData> eventList) {
		this.eventList = eventList;
	}

	public String getShipmentEventId() {
		return ShipmentEventId;
	}

	public void setShipmentEventId(String shipmentEventId) {
		ShipmentEventId = shipmentEventId;
	}

	public String getSOEID() {
		return SOEID;
	}

	public void setSOEID(String sOEID) {
		SOEID = sOEID;
	}

	public String getEventId() {
		return EventId;
	}

	public void setEventId(String eventId) {
		EventId = eventId;
	}

	public String getData() {
		return Data;
	}

	public void setData(String data) {
		Data = data;
	}

	public String getTrackingId() {
		return TrackingId;
	}

	public void setTrackingId(String trackingId) {
		TrackingId = trackingId;
	}

	public String getOriginatorId() {
		return OriginatorId;
	}

	public void setOriginatorId(String originatorId) {
		OriginatorId = originatorId;
	}

	public String getCreationDateTime() {
		return CreationDateTime;
	}

	public void setCreationDateTime(String creationDateTime) {
		CreationDateTime = creationDateTime;
	}

	public String getMailSentCountry() {
		return MailSentCountry;
	}

	public void setMailSentCountry(String mailSentCountry) {
		MailSentCountry = mailSentCountry;
	}

	public String getContainerNo() {
		return ContainerNo;
	}

	public void setContainerNo(String containerNo) {
		ContainerNo = containerNo;
	}

	public String getPubDateTime() {
		return PubDateTime;
	}

	public void setPubDateTime(String pubDateTime) {
		PubDateTime = pubDateTime;
	}

	public String getMailSentPort() {
		return MailSentPort;
	}

	public void setMailSentPort(String mailSentPort) {
		MailSentPort = mailSentPort;
	}

	public String getCargoType() {
		return CargoType;
	}

	public void setCargoType(String cargoType) {
		CargoType = cargoType;
	}

	public String getGPSCoordinates() {
		return GPSCoordinates;
	}

	public void setGPSCoordinates(String gPSCoordinates) {
		GPSCoordinates = gPSCoordinates;
	}

	public String getTrackflag() {
		return Trackflag;
	}

	public void setTrackflag(String trackflag) {
		Trackflag = trackflag;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getCountryId() {
		return CountryId;
	}

	public void setCountryId(String countryId) {
		CountryId = countryId;
	}

	public String getPortId() {
		return PortId;
	}

	public void setPortId(String portId) {
		PortId = portId;
	}

	public String getOriginatorName() {
		return OriginatorName;
	}

	public void setOriginatorName(String originatorName) {
		OriginatorName = originatorName;
	}

	public String getEventDataType() {
		return EventDataType;
	}

	public void setEventDataType(String eventDataType) {
		EventDataType = eventDataType;
	}

	public String getDocumentType() {
		return DocumentType;
	}

	public void setDocumentType(String documentType) {
		DocumentType = documentType;
	}

	public String getDocumentHashKey() {
		return DocumentHashKey;
	}

	public void setDocumentHashKey(String documentHashKey) {
		DocumentHashKey = documentHashKey;
	}

	public String getDocumentPublicKey() {
		return DocumentPublicKey;
	}

	public void setDocumentPublicKey(String documentPublicKey) {
		DocumentPublicKey = documentPublicKey;
	}

	public String getDelegationId() {
		return DelegationId;
	}

	public void setDelegationId(String delegationId) {
		DelegationId = delegationId;
	}

	public String getDocumentURI() {
		return DocumentURI;
	}

	public void setDocumentURI(String documentURI) {
		DocumentURI = documentURI;
	}

	public String getLocationType() {
		return LocationType;
	}

	public void setLocationType(String locationType) {
		LocationType = locationType;
	}

	public String getSHIPMENTEVENTID() {
		return SHIPMENTEVENTID;
	}

	public void setSHIPMENTEVENTID(String sHIPMENTEVENTID) {
		SHIPMENTEVENTID = sHIPMENTEVENTID;
	}

	public String getLocationOrder() {
		return locationOrder;
	}

	public void setLocationOrder(String locationOrder) {
		this.locationOrder = locationOrder;
	}

	public String getEvent_countryid() {
		return event_countryid;
	}

	public void setEvent_countryid(String event_countryid) {
		this.event_countryid = event_countryid;
	}

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public String getEVENT_PORTID() {
		return EVENT_PORTID;
	}

	public void setEVENT_PORTID(String eVENT_PORTID) {
		EVENT_PORTID = eVENT_PORTID;
	}

	public String getShipmentEventID() {
		return ShipmentEventID;
	}

	public void setShipmentEventID(String shipmentEventID) {
		ShipmentEventID = shipmentEventID;
	}

	public LinkedHashMap<String, ArrayList<EventData>> getPortwiseEventData() {
		return portwiseEventData;
	}

	public void setPortwiseEventData(
			LinkedHashMap<String, ArrayList<EventData>> portwiseEventData) {
		this.portwiseEventData = portwiseEventData;
	}

}
