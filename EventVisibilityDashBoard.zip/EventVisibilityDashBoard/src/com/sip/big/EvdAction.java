package com.sip.big;

import java.io.IOException;
import java.io.StringReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLXML;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.opensymphony.xwork2.ActionSupport;

public class EvdAction extends ActionSupport {

	private static final long serialVersionUID = 1L;
	private String userName;
	private String password;
	private String SOEId;
	private String containerNo;
	private String trackingId;
	private String bolNo;
	private String toDate;
	private String fromDate;
	//private String eventName;
	private String eventId;
	private String portId;
	private EventDetails eventDetailsobj = new EventDetails();
	private String errorMsg = null;

	private static Logger logger = Logger.getLogger("SIPAPP");

	public EventDetails getEventDetailsobj() {
		return eventDetailsobj;
	}

	public void setEventDetailsobj(EventDetails eventDetailsobj) {
		this.eventDetailsobj = eventDetailsobj;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public String getPortId() {
		return portId;
	}

	public void setPortId(String portId) {
		this.portId = portId;
	}



	ConnectionUtil connUtil = new ConnectionUtil();
	List<EventDetailsBean> resultList = new ArrayList<EventDetailsBean>();
	private EventDetailsBean eventDetailsBeanObj = new EventDetailsBean();

	public EventDetailsBean getEventDetailsBeanObj() {
		return eventDetailsBeanObj;
	}

	public void setEventDetailsBeanObj(EventDetailsBean eventDetailsBeanObj) {
		this.eventDetailsBeanObj = eventDetailsBeanObj;
	}

	public List<EventDetailsBean> getResultList() {
		return resultList;
	}

	public void setResultList(List<EventDetailsBean> resultList) {
		this.resultList = resultList;
	}

	public String getContainerNo() {
		return containerNo;
	}

	public void setContainerNo(String containerNo) {
		this.containerNo = containerNo;
	}

	public String getTrackingId() {
		return trackingId;
	}

	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}

	public String getBolNo() {
		return bolNo;
	}

	public void setBolNo(String bolNo) {
		this.bolNo = bolNo;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getSOEId() {
		return SOEId;
	}

	public void setSOEId(String sOEId) {
		SOEId = sOEId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String searchSIP() {
		logger.info("Entering searchSIP() of EvdAction in EVD");
		String returnType = "SUCCESS";
		
		if ((null == this.trackingId || "".equals(this.trackingId))
				&& (null == this.containerNo || "".equals(this.containerNo))
				&& (null == this.bolNo || "".equals(this.bolNo))){
			addActionError("Please provide any one of the field : Container-No. OR Tracking-ID OR BOL No.");
			return ERROR;
		}
		
		EventDetailsBean eventDetailsBean = new EventDetailsBean();
		String transportPlan = fetchToSQLXML();

		if (errorMsg != null) {
			addActionError(errorMsg);
			return ERROR;
		}

		try {
			if (transportPlan == null) {
				eventDetailsBean = fetchBigScreenData(this.trackingId, this.containerNo, this.bolNo, this.fromDate, this.toDate, null);
				eventDetailsBeanObj = eventDetailsBean;
			} else {
				Map<String, Map<String, String>> transportationMap = getDataFromTransportationPlan(transportPlan);
				/*
				 * Iterator<Entry<String, Map<String, String>>> it =
				 * transportationMap.entrySet().iterator(); while (it.hasNext())
				 * { Map.Entry<String, Map<String, String>> pair = it.next(); }
				 */
				eventDetailsBean = fetchBigScreenData(this.trackingId, this.containerNo, this.bolNo, this.fromDate, this.toDate, transportationMap);
				eventDetailsBeanObj = eventDetailsBean;
			}
		} catch (Exception e) {
			logger.error("Exception caught in searchSIP() of EvdAction in EVD " + e.getMessage());
			returnType = ERROR;
			System.out.println("returnType " + returnType + " = " + e.getMessage());
		}
		logger.info("Exiting searchSIP() of EvdAction in EVD " + resultList);

		return returnType;

	}

	public Connection getConnection() {
		Connection con = null;
		if (con == null) {
			try {
				Context initContext = new InitialContext();
				Context envContext = (Context) initContext.lookup("java:/comp/env");
				DataSource ds = (DataSource) envContext.lookup("jdbc/sip_foundation");
				con = ds.getConnection();
			} catch (NamingException e) {
				e.getMessage();
			} catch (SQLException sqlEx) {
				sqlEx.getMessage();
			}
		}
		return con;
	}

	public String fetchToSQLXML() {
		logger.info("Entering fetchToSQLXML() of EvdAction in EVD");
		PreparedStatement selectStmt = null;
		String sqls = null, stringDoc = null;
		ResultSet rs = null;
		SQLXML xml = null;
		Connection connection = null;
		boolean isContainerNo = false, isResultFound = false;

		try {
			connection = getConnection();
			if (null != this.trackingId && !"".equals(this.trackingId)) {
				sqls = "select a.DATA, a.EventDataType from sip_foundation.event_details a where a.TRACKINGID='"
						+ trackingId + "'";
			} else if (null != this.containerNo && !"".equals(this.containerNo)) {
				isContainerNo = true;
				sqls = "select a.DATA, a.EventDataType from sip_foundation.event_details a,sip_foundation.events_container c, sip_foundation.association aa "
						+ "where a.shipmenteventid=c.ShipmentEventId and aa.containerNo=c.containerNo and aa.TrackingId=a.TrackingId "
						+ "and c.containerNo='" + containerNo + "'";
			}
			selectStmt = connection.prepareStatement(sqls);
			rs = selectStmt.executeQuery();
			while (rs.next()) {
				isResultFound = true;
				if (rs.getString("a.EventDataType") != null && rs.getString("a.EventDataType").trim().equals("Transport Plan")) {
					xml = rs.getSQLXML(1);
					stringDoc = xml.getString();
				}
			}
			rs.close();
		} catch (SQLException sqle) {
			logger.error("Exception caught in fetchToSQLXML() of EvdAction in EVD " + sqle.getMessage());
		} finally {
			connUtil.closeAll(connection, null, selectStmt, rs);
		}

		if (isContainerNo && !isResultFound)
			errorMsg = "The Container Number " + containerNo + " is not associated with any Tracking Id";

		logger.info("Exiting fetchToSQLXML() of EvdAction in EVD");
		return stringDoc;
	}

	public Map<String, Map<String, String>> getDataFromTransportationPlan(String xmlData) throws Exception{

		logger.info("Entering getDataFromTransportationPlan() of EvdAction in EVD");

		TreeMap<String, Map<String, String>> transportationMap = new TreeMap<String, Map<String, String>>();
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = null;
		try {
			builder = factory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			logger.error("Exception caught in getDataFromTransportationPlan() of EvdAction in EVD " + e.getMessage());
			throw new Exception(e);
		}
		Document doc = null;
		try {
			if (builder != null) {
				doc = builder.parse(new InputSource(new StringReader(xmlData)));
			}
		} catch (SAXException | IOException e) {
			logger.error("Exception caught in getDataFromTransportationPlan() of EvdAction in EVD " + e.getMessage());
			throw new Exception(e);
		}
		if (doc != null) {
			doc.getDocumentElement().normalize();
		}
		String rootElement = doc.getDocumentElement().getNodeName();
		if (null != rootElement && "TransportPlan".equalsIgnoreCase(rootElement)) {
			NodeList legIdNode = doc.getElementsByTagName("LegID");
			for (int i = 0; i < legIdNode.getLength(); i++) {
				Map<String, String> transportPlan = new HashMap<String, String>();
				Node legId = legIdNode.item(i);
				if (legId.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) legId;
					String id = eElement.getAttribute("id");
					if (id.length() > 0) {
						transportPlan.put("VoyageNo",
								eElement.getElementsByTagName("VoyageNo").item(0).getTextContent());
						transportPlan.put("VesselName",
								eElement.getElementsByTagName("VesselName").item(0).getTextContent());
						transportPlan.put("TransportID",
								eElement.getElementsByTagName("TransportID").item(0).getTextContent());
						transportPlan.put("ImoNO", eElement.getElementsByTagName("ImoNO").item(0).getTextContent());
						transportPlan.put("FromLocation",
								eElement.getElementsByTagName("FromLocation").item(0).getTextContent());
						transportPlan.put("ToLocation",
								eElement.getElementsByTagName("ToLocation").item(0).getTextContent());
						transportPlan.put("TransportType",
								eElement.getElementsByTagName("TransportType").item(0).getTextContent());
						transportPlan.put("EstimatedDepTime",
								eElement.getElementsByTagName("EstimatedDepTime").item(0).getTextContent());
						transportPlan.put("EstimatedArrTime",
								eElement.getElementsByTagName("EstimatedArrTime").item(0).getTextContent());
						transportPlan.put("FromLocType",
								eElement.getElementsByTagName("FromLocType").item(0).getTextContent());
						transportPlan.put("ToLocType",
								eElement.getElementsByTagName("ToLocType").item(0).getTextContent());
						transportationMap.put(id, transportPlan);
					}
				}
			}
		}

		logger.info("Exiting getDataFromTransportationPlan() of EvdAction in EVD");
		return transportationMap;

	}

	public EventDetailsBean getTransportPlanData() {
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		Connection connection = null;
		connection = getConnection();
		try {
			preparedStatement = connection
					.prepareStatement("select a.DATA, a.EventDataType from sip_foundation.event_details a");

			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) 
			  resultSet.getSQLXML("a.DATA");
		} catch (SQLException e) {
			logger.error("Exception caught in getTransportPlanData() of EvdAction in EVD " + e.getMessage());
		} finally {
			connUtil.closeAll(connection, null, preparedStatement, resultSet);
		}
		return eventDetailsBeanObj;
	} 
	
	public EventDetailsBean fetchBigScreenData(String trackingId, String containerNo, String bolNo, String fromDate, String toDate,
			Map<String, Map<String, String>> transportPlan) throws Exception{

		logger.info("Entering fetchBigScreenData() of EvdAction in EVD");

		EventDetailsBean eventDetailsBean = new EventDetailsBean();
		eventDetailsBean.setInContainerNo(containerNo);
		eventDetailsBean.setInTrackingId(trackingId);
		eventDetailsBean.setInBolNo(bolNo);
		eventDetailsBean.setInFromDate(fromDate);
		eventDetailsBean.setInToDate(toDate);
		StringBuffer queryCondition = new StringBuffer();
		StringBuffer getQueryEvents = new StringBuffer();
		PreparedStatement stm = null;
		ResultSet events_rs = null;
		Connection con = null;
		boolean flag = false;
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH);
		List<String> estimatedDepTimeList = new ArrayList<String>();
		List<String> estimatedArrTimeList = new ArrayList<String>();
		List<String> contDischargeFromPortList = new ArrayList<String>();
		Map<String, String> estimatedDepTimeMap = null;
		Map<String, String> estimatedArrTimeMap = null;
		Map<String, String> actualDepTimeMap = null;
		Map<String, String> actualArrTimeMap = null;
		EventData eventDataObj = null;

		try {
			con = getConnection();
			String shipmentEventIds = "";
			if (!"".equalsIgnoreCase(trackingId)) {
				flag = true;
				queryCondition.append("a.trackingId = '" + trackingId + "' ");
			}

			if (!"".equalsIgnoreCase(containerNo)) {
				try {
					stm = con.prepareStatement("select * from events_container");
					events_rs = stm.executeQuery();
					while (events_rs.next()) {
						if (events_rs.getString("CONTAINERNO") != null) {
							ArrayList<String> containerList = new ArrayList<String>(
									Arrays.asList(events_rs.getString("CONTAINERNO").toUpperCase().split(",")));
							if (containerList.contains(containerNo.toUpperCase())) {
								if ("".equals(shipmentEventIds)) {
									shipmentEventIds = events_rs.getString("ShipmentEventId");
								} else {
									shipmentEventIds = shipmentEventIds + "," + events_rs.getString("ShipmentEventId");
								}
							}
						}
					}
				} catch (SQLException e) {
					logger.error("Exception caught in fetchBigScreenData() of EvdAction in EVD " + e.getMessage());
					throw new Exception(e);
				} finally {
					connUtil.closeAll(null, stm, null, events_rs);
				}
			}
			if(!"".equalsIgnoreCase(bolNo)){
				if (flag) {
					queryCondition.append(" and a.EventDataType = 'BoL no' and a.DATA = '" + bolNo + "' " );
				} else {
					queryCondition.append(" a.EventDataType = 'BoL no' and a.DATA = '" + bolNo + "' ");
					flag = true;
				}
			}
			if (!"".equalsIgnoreCase(fromDate) && !"".equalsIgnoreCase(toDate)) {
				Date parsedFromDate = dateFormat.parse(fromDate);
				Date parsedToDate = dateFormat.parse(toDate);
				Timestamp startTimeVal = new java.sql.Timestamp(parsedFromDate.getTime());
				Timestamp endTimeVal = new java.sql.Timestamp(parsedToDate.getTime());

				if (flag) {
					queryCondition.append(" and a.CREATIONDATETIME between '" + startTimeVal + "' and '" + endTimeVal + "' ");
				} else {
					queryCondition.append(" a.CREATIONDATETIME between '" + startTimeVal + "' and '" + endTimeVal + "' ");
					flag = true;
				}
			}
			if ("".equalsIgnoreCase(fromDate) && !"".equalsIgnoreCase(toDate)) {
				Date parsedToDate = dateFormat.parse(toDate);
				Timestamp endTimeVal = new java.sql.Timestamp(parsedToDate.getTime());

				if (flag) {
					queryCondition.append(" and a.CREATIONDATETIME < '" + endTimeVal + "' ");
				} else {
					queryCondition.append(" a.CREATIONDATETIME  < '" + endTimeVal + "' ");
					flag = true;
				}
			}
			if (!"".equalsIgnoreCase(fromDate) && "".equalsIgnoreCase(toDate)) {
				Date parsedFromDate = dateFormat.parse(fromDate);
				Timestamp startTimeVal = new java.sql.Timestamp(parsedFromDate.getTime());

				if (flag) {
					queryCondition.append(" and a.CREATIONDATETIME > '" + startTimeVal + "' ");
				} else {
					queryCondition.append(" a.CREATIONDATETIME > '" + startTimeVal + "' ");
					flag = true;
				}
			}

			if (!"".equals(shipmentEventIds)) {
				if (flag) {
					queryCondition.append(" and a.SHIPMENTEVENTID in (" + shipmentEventIds + ")");
				} else {
					queryCondition.append(" a.SHIPMENTEVENTID in (" + shipmentEventIds + ")");
					flag = true;
				}
			} else { // For no shipmentId for the given container number
				if (!"".equalsIgnoreCase(containerNo)) {
					if (flag) {
						queryCondition.append(" and false");
					} else {
						queryCondition.append(" false ");
						flag = true;
					}
				}
			}

			getQueryEvents.append("SELECT a.SHIPMENTEVENTID, \n");
			getQueryEvents.append("		  a.SOEID, \n");
			getQueryEvents.append("       a.EVENTID, \n");
			getQueryEvents.append("       ( \n");
			getQueryEvents.append("			SELECT eventname from sip_foundation.event_type where eventId=a.EVENTID \n");
			getQueryEvents.append("		  ) eventname, \n");
			getQueryEvents.append("		  DATE_FORMAT(a.PUBDATETIME,'%Y-%m-%d %H:%i') as PUBDATETIME, \n");
			getQueryEvents.append("       if(a.EventDataType = 'Date and Time', DATE_FORMAT(a.data,'%Y-%m-%d %H:%i') , a.data) as data, \n");
			getQueryEvents.append("       a.CARGOTYPE, \n");
			getQueryEvents.append("       ( \n");
			getQueryEvents.append("			SELECT GROUP_CONCAT(containerNo) FROM sip_foundation.events_container ec WHERE ec.ShipmentEventId = a.ShipmentEventId \n");
			getQueryEvents.append("		  ) CONTAINERNO, \n");
			getQueryEvents.append("		  a.COUNTRYID, \n");
			getQueryEvents.append("		  a.PORTID, \n");
			getQueryEvents.append("		  a.TRACKINGID, \n");
			getQueryEvents.append("		  a.ORIGINATORID, \n");
			getQueryEvents.append("		  DATE_FORMAT(a.CREATIONDATETIME,'%Y-%m-%d %H:%i') as CREATIONDATETIME, \n");
			getQueryEvents.append("		  a.location, \n");
			getQueryEvents.append("		  a.OriginatorName, \n");
			getQueryEvents.append("		  a.EventDataType, \n");
			getQueryEvents.append("		  a.DocumentURI, \n");
			getQueryEvents.append("		  a.DocumentType, \n");
			getQueryEvents.append("		  a.LocationType, \n");
			getQueryEvents.append("		  IFNULL(a.LocationType,'NA') location_type, \n");
			getQueryEvents.append("		  (SELECT \n");
			getQueryEvents.append("		     CASE \n");
			getQueryEvents.append("		       WHEN a.EVENTID = 'E278' THEN \n");
			getQueryEvents.append("		         (SELECT GROUP_CONCAT(cl.countryname separator '~') from events_country ec,country_loc cl where ec.event_countryid=cl.countryid and ec.shipmenteventid=a.SHIPMENTEVENTID order by ec.locationOrder asc) \n");
			getQueryEvents.append("		       ELSE \n");
			getQueryEvents.append("		         (SELECT GROUP_CONCAT(cl.countryname separator '~') from events_country ec,country_loc cl where ec.event_countryid=cl.countryid and ec.shipmenteventid=a.SHIPMENTEVENTID) \n");
			getQueryEvents.append("            END \n");
			getQueryEvents.append("       ) AS countryname, \n");
			getQueryEvents.append("		  (SELECT \n");
			getQueryEvents.append("		     CASE \n");
			getQueryEvents.append("		       WHEN a.EVENTID = 'E278' THEN \n");
			getQueryEvents.append("		         (SELECT GROUP_CONCAT(pl.portname separator '~') from events_port ep,port_loc pl where ep.event_portid=pl.portid and ep.shipmenteventid=a.SHIPMENTEVENTID order by locationOrder asc) \n");
			getQueryEvents.append("		       ELSE \n");
			getQueryEvents.append("		         (SELECT GROUP_CONCAT(pl.portname separator '~') from events_port ep,port_loc pl where ep.event_portid=pl.portid and ep.shipmenteventid=a.SHIPMENTEVENTID) \n");
			getQueryEvents.append("            END \n");
			getQueryEvents.append("       ) AS portname \n");
			getQueryEvents.append("FROM sip_foundation.event_details a \n");

			if (!"".equalsIgnoreCase(queryCondition.toString())) {
				getQueryEvents.append("where ").append(queryCondition);
			}
			getQueryEvents.append(" ORDER BY a.creationdatetime asc limit 0,1000");
			logger.info("In first condition \n" + getQueryEvents);

			stm = con.prepareStatement(getQueryEvents.toString());
			events_rs = stm.executeQuery();
			// String location = StringUtils.EMPTY;
			// String shipID = StringUtils.EMPTY;
			String eventId = StringUtils.EMPTY;
			String eventCountryId = StringUtils.EMPTY;
			String eventPortId = StringUtils.EMPTY;
			LinkedHashMap<String, ArrayList<EventData>> portwiseEventMap = eventDetailsBean.getPortwiseEventData();
			String oldPortId = null;
			boolean stratContainerFlag = true;
			estimatedDepTimeMap = new LinkedHashMap<String, String>();
			estimatedArrTimeMap = new LinkedHashMap<String, String>();
			actualDepTimeMap = new LinkedHashMap<String, String>();
			actualArrTimeMap = new LinkedHashMap<String, String>();
			int count = 0;
			ArrayList<String> toLocationList = new ArrayList<String>();
			ArrayList<String> fromLocationList = new ArrayList<String>();
			List<String> eventPortIdList = new ArrayList<String>();
            
			while (events_rs.next()) {
				eventDetailsBean.setShipmentEventId(events_rs.getString("a.SHIPMENTEVENTID"));
				eventDetailsBean.setSOEID(events_rs.getString("a.SOEID"));
				eventDetailsBean.setPubDateTime(events_rs.getString("PUBDATETIME"));
				eventDetailsBean.setEventId(events_rs.getString("a.EVENTID"));
				String cargoEventId = events_rs.getString("a.EVENTID");
				eventDetailsBean.setTrackingId(events_rs.getString("a.TRACKINGID"));
				if ("E278".equalsIgnoreCase(cargoEventId)) {
					eventDetailsBean.setCargoType(events_rs.getString("a.CARGOTYPE"));
				}
				if ("E265".equalsIgnoreCase(cargoEventId)) {
					eventDetailsBean.setVgm(events_rs.getString("DATA"));
				}
				if ("E311".equalsIgnoreCase(cargoEventId)) {
					eventDetailsBean.setContainerTypeSize(events_rs.getString("DATA"));
				}
				if ("E267".equalsIgnoreCase(cargoEventId)) {
					eventDetailsBean.setDangerousGoods("Yes");
				}
				String bolEventDataType = events_rs.getString("a.EventDataType");
				if ("BoL no".equalsIgnoreCase(bolEventDataType)) {
					eventDetailsBean.setBolNumber(events_rs.getString("DATA"));
				}

				eventDetailsBean.setData(events_rs.getString("DATA"));
				String containerNos = events_rs.getString("CONTAINERNO");
				if (!"".equalsIgnoreCase(containerNos) && null != containerNos) {
					HashSet<String> containerList = new HashSet<String>(Arrays.asList(containerNos.split(",")));
					eventDetailsBean.getContainerNoList().addAll(containerList);
				}
				eventDetailsBean.setOriginatorName(events_rs.getString("a.OriginatorName"));

				eventDataObj = new EventData();
				eventId = events_rs.getString("a.EVENTID").trim();
				eventDataObj.setEventId(eventId);
				eventDataObj.setOriginatorName(events_rs.getString("a.OriginatorName"));
				eventDataObj.setEventDataType(events_rs.getString("a.EventDataType"));
				eventDataObj.setEventName(events_rs.getString("eventname"));
				eventDataObj.setCreationDateTime("" + events_rs.getString("creationdatetime"));
				eventDataObj.setPortId(events_rs.getString("a.PORTID"));
				String documentURI = events_rs.getString("a.DocumentURI");
				if (documentURI != null && documentURI.trim().length() > 0 && documentURI.contains("?dl=")) {
					documentURI = documentURI.substring(0, documentURI.indexOf("?dl=")) + "?dl=1";
				}
				eventDataObj.setDocumentURI(documentURI);
				eventDataObj.setDocumenType(events_rs.getString("a.DocumentType"));

				if (eventId.equalsIgnoreCase("E276")) {
					eventDataObj.setEventData(events_rs.getString("DATA") + "Degrees" + " F");
				} else {
					eventDataObj.setEventData(events_rs.getString("DATA"));
				}
				eventDetailsBean.getEventList().add(eventDataObj);
				eventCountryId = events_rs.getString("a.COUNTRYID");
				eventPortId = events_rs.getString("a.PORTID");

				if ("E266".equals(eventId) && eventPortId != null) {
					String date = events_rs.getString("DATA");
					eventPortIdList.add(eventPortId + "~ETDischarge" + date);
				}
				if ("E306".equals(eventId) && eventPortId != null) {
					String date = events_rs.getString("DATA");
					eventPortIdList.add(eventPortId + "~ATDischarge" + date);
				}

				if (null == transportPlan) {
					if ("E280".equals(eventId) && (null != eventPortId) && !(events_rs.getString("DATA").isEmpty())) {
						String date = events_rs.getString("DATA");
						actualArrTimeMap.put(eventPortId.trim(), date);
					}
					if ("E310".equals(eventId) && (null != eventPortId) && !(events_rs.getString("DATA").isEmpty())) {
						String date = events_rs.getString("DATA");
						estimatedArrTimeMap.put(eventPortId.trim(), date);
					}
					if ("E025".equals(eventId) && (null != eventPortId) && !(events_rs.getString("DATA").isEmpty())) {
						String date = events_rs.getString("DATA");
						actualDepTimeMap.put(eventPortId.trim(), date);
					}
					 if ("E034".equals(eventId) && (null != eventPortId) && !(events_rs.getString("DATA").isEmpty())) {
						 String date = events_rs.getString("DATA");
						estimatedDepTimeMap.put(eventPortId.trim(), date);
					}
				}
	            //customize the key value of hash map portwiseEventMap which is showing in below of the screen
				/*if (eventPortId != null) {
					//if port details exists in the port_loc table for the portid 
					if (events_rs.getString("portname") != null && events_rs.getString("portname").indexOf('-') != -1) {
						eventPortId = events_rs.getString("portname");
						String ss[] = eventPortId.split("-");
						eventPortId = ss[1].replaceAll("\u00A0","")+" ("+ ss[0].replaceAll("\u00A0","")+")";
					}
				} else*/ if (eventPortId == null && eventCountryId != null) {
					eventPortId = eventCountryId;
				}
				if (eventPortId != null) {
					stratContainerFlag = false;
				}
				if (stratContainerFlag) {
					if (portwiseEventMap.get("STCEvent") == null) {
						ArrayList<EventData> listObj = portwiseEventMap.get("STCEvent") == null
								? new ArrayList<EventData>() : portwiseEventMap.get("STCEvent");
						listObj.add(eventDataObj);
						portwiseEventMap.put("STCEvent", listObj);
					} else {
						ArrayList<EventData> eventList = portwiseEventMap.get("STCEvent");
						eventList.add(eventDataObj);
					}
				} else {
					if (eventPortId == null && eventCountryId != null) {
						eventPortId = eventCountryId;
					}
					if (eventPortId != null) {
						if (portwiseEventMap.get(eventPortId) == null) {
							ArrayList<EventData> listObj = portwiseEventMap.get(eventPortId) == null ? new ArrayList<EventData>()
									: portwiseEventMap.get(eventPortId);
							listObj.add(eventDataObj);
							portwiseEventMap.put(eventPortId, listObj);
						} else {
							ArrayList<EventData> eventList = portwiseEventMap.get(eventPortId);
							eventList.add(eventDataObj);
						}
					} else {
						if (portwiseEventMap.get(oldPortId) == null) {
							ArrayList<EventData> listObj = portwiseEventMap.get(oldPortId) == null
									? new ArrayList<EventData>()
									: portwiseEventMap.get(oldPortId);
							listObj.add(eventDataObj);
							portwiseEventMap.put(eventPortId, listObj);
						} else {
							ArrayList<EventData> eventList = portwiseEventMap.get(oldPortId);
							eventList.add(eventDataObj);
						}
					}
					if (eventPortId != null)
						oldPortId = eventPortId;
				}
				// location = getCountryPortViaShipId(shipID, eventId);

				toLocationList = new ArrayList<String>();
				fromLocationList = new ArrayList<String>();
				if (null != transportPlan) {
					Iterator<Entry<String, Map<String, String>>> it = transportPlan.entrySet().iterator();
					estimatedDepTimeList = new ArrayList<String>();
					estimatedArrTimeList = new ArrayList<String>();
					int i = transportPlan.size();
					String lastPortLocation = null;
					int j = 0;
					while (it.hasNext()) {
						Map.Entry<String, Map<String, String>> pair = it.next();
						Iterator entries = ((Map) pair.getValue()).entrySet().iterator();
						j++;
						while (entries.hasNext()) {
							Entry thisEntry = (Entry) entries.next();

							if (thisEntry.getKey() == "FromLocation") {
								toLocationList.add((String) thisEntry.getValue());
							}
							if (i == j && thisEntry.getKey() == "ToLocation") {
								lastPortLocation = (String) thisEntry.getValue();
							}
							if (j > 1 && "EstimatedArrTime".equals(thisEntry.getKey())) {
								estimatedArrTimeList.add((String) thisEntry.getValue());
							}
							if (j == 1 && "EstimatedArrTime".equals(thisEntry.getKey())) {
								estimatedArrTimeList.add("");
								estimatedArrTimeList.add((String) thisEntry.getValue());
							} else if ("EstimatedDepTime".equals(thisEntry.getKey())) {
								estimatedDepTimeList.add((String) thisEntry.getValue());
							}
						}
					}

					toLocationList.add(lastPortLocation);
				}

				// calculate location and route
				if ("E278".equalsIgnoreCase(eventId)) {
					if (events_rs.getString("countryname") != null) {
						String ss[] = events_rs.getString("countryname").split("~");
						String fromCountry = ss[0];
						String toCountry = ss[1];
						eventDetailsBean.setFromCountry(fromCountry);
						eventDetailsBean.setToCountry(toCountry);
					}
					String route = events_rs.getString("portname");
					if (toLocationList.isEmpty()) {
						if (route != null)
							eventDetailsBean.setRoute(new ArrayList<String>(Arrays.asList(route.split("~"))));
					} else {
						eventDetailsBean.setRoute(toLocationList);
					}

					// standard format is fromCountry(route)toCountry as defined
					// in getCountryPortViaShipId
					// route can be a single port or comma separated ports
					// split location like Kenya(OMSLV-Salalah)United States
					/*
					 * if (location.contains("[") && location.contains("]")) {
					 * String ss[] = location.split("\\["); String fromCountry =
					 * ss[0]; String fc[] = ss[1].split("\\]"); String toCountry
					 * = fc[1]; String route = fc[0];
					 * 
					 * eventDetailsBean.setFromCountry(fromCountry);
					 * eventDetailsBean.setToCountry(toCountry); if
					 * (toLocationList.isEmpty()) {
					 * eventDetailsBean.setRoute(new
					 * ArrayList<String>(Arrays.asList(route.split(",")))); }
					 * else { eventDetailsBean.setRoute(toLocationList); } }
					 */
				} else {
				}
			}

			for (int i = 0; i < eventDetailsBean.getRoute().size(); i++) {
				if (i == eventDetailsBean.getRoute().size() - 1) {
					boolean isETDischarge = false;
					for (int j = 0; j < eventPortIdList.size(); j++) {
						if (transportPlan != null) {
							if (eventDetailsBean.getRoute().get(i).equals(eventPortIdList.get(j))) {
								contDischargeFromPortList.add("Container Discharged");
							}
						} else {

							String portCountry = eventDetailsBean.getRoute().get(i);
							String[] ports = portCountry.split("-");
							String port = ports[0].replaceAll("\u00A0", "");
							String portIdAndData = eventPortIdList.get(j);
							String[] portIdAndDataArr = portIdAndData.split("~");
							String porId = portIdAndDataArr[0];
							String data = portIdAndDataArr[1];
							String discharge = data.substring(0, 11);
							if ("ATDischarge".equals(discharge)) {
								if (port.trim().equals(porId)) {
									contDischargeFromPortList.add("ATDischarge " + data.substring(11, data.length()));
									isETDischarge = true;
								}
							}
						}
					}

					if (!isETDischarge) {
						for (int j = 0; j < eventPortIdList.size(); j++) {

							String portCountry = eventDetailsBean.getRoute().get(i);
							String[] ports = portCountry.split("-");
							String port = ports[0].replaceAll("\u00A0", "");
							String portIdAndData = eventPortIdList.get(j);
							String[] portIdAndDataArr = portIdAndData.split("~");
							String porId = portIdAndDataArr[0];
							String data = portIdAndDataArr[1];
							String discharge = data.substring(0, 11);
							if ("ETDischarge".equals(discharge)) {
								if (port.trim().equals(porId)) {
									contDischargeFromPortList.add("ETDischarge " + data.substring(11, data.length()));
								}
							}
						}
					}
				}

				else {
					contDischargeFromPortList.add("");
				}
			}

			eventDetailsBean.setEstimatedDepTime(estimatedDepTimeList);
			eventDetailsBean.setEstimatedArrTime(estimatedArrTimeList);
			eventDetailsBean.setContDischargeFromPortList(contDischargeFromPortList);

			Set<String> keySet = portwiseEventMap.keySet();
			Iterator<String> keySetIterator = keySet.iterator();
			LinkedHashMap<String, ArrayList<EventData>> finalProtEventMap = new LinkedHashMap<String, ArrayList<EventData>>();

			while (keySetIterator.hasNext()) {
				String key = (String) keySetIterator.next();
				if ("STCEvent".equalsIgnoreCase(key)) {
					ArrayList<EventData> stcList = eventDetailsBean.getPortwiseEventData().get("STCEvent");
					finalProtEventMap.put(eventDetailsBean.getFromCountry(), stcList);
				} else {
					ArrayList<EventData> stcList = eventDetailsBean.getPortwiseEventData().get(key);
					finalProtEventMap.put(key, stcList);
				}
			}
			eventDetailsBean.setPortwiseEventData(finalProtEventMap);

			count = 0;
			int firstOccurenceofEtdCount = 0;
			String key = null;
			keySet = finalProtEventMap.keySet();
			keySetIterator = keySet.iterator();
			while (keySetIterator.hasNext()) {
				key = (String) keySetIterator.next();
				// not calculating ETA & ETD for From Country
				if (count == 0) {
					count++;
					continue;
				}

				if (actualArrTimeMap.get(key) != null && actualDepTimeMap.get(key) != null) {
					estimatedArrTimeList.add("ATA " + actualArrTimeMap.get(key));
					estimatedDepTimeList.add("ATD " + actualDepTimeMap.get(key));
					// continue;
				} else if (actualArrTimeMap.get(key) != null && estimatedDepTimeMap.get(key) != null) {
					estimatedArrTimeList.add("ATA " + actualArrTimeMap.get(key));
					estimatedDepTimeList.add("ETD " + estimatedDepTimeMap.get(key));
					// continue;
				} else if (estimatedArrTimeMap.get(key) != null && actualDepTimeMap.get(key) != null) {
					estimatedArrTimeList.add("ETA " + estimatedArrTimeMap.get(key));
					estimatedDepTimeList.add("ATD " + actualDepTimeMap.get(key));
					// continue;
				} else if (estimatedArrTimeMap.get(key) != null && estimatedDepTimeMap.get(key) != null) {
					estimatedArrTimeList.add("ETA " + estimatedArrTimeMap.get(key));
					estimatedDepTimeList.add("ETD " + estimatedDepTimeMap.get(key));
					// continue;
				} else if (actualArrTimeMap.get(key) != null) {
					estimatedArrTimeList.add("ATA " + actualArrTimeMap.get(key));
					estimatedDepTimeList.add("");
					// continue;
				} else if (actualDepTimeMap.get(key) != null) {
					estimatedDepTimeList.add("ATD " + actualDepTimeMap.get(key));
					estimatedArrTimeList.add("");
				} else if (estimatedArrTimeMap.get(key) != null) {
					estimatedArrTimeList.add("ETA " + estimatedArrTimeMap.get(key));
					estimatedDepTimeList.add("");
				} else if (estimatedDepTimeMap.get(key) != null) {
					estimatedDepTimeList.add("ETD " + estimatedDepTimeMap.get(key));
					estimatedArrTimeList.add("");
				}
			}
				

			for (Map.Entry<String, ArrayList<EventData>> entry : finalProtEventMap.entrySet()) {
				String port = entry.getKey();
				ArrayList<EventData> eventDataList = entry.getValue();
				boolean etdOrETaFound = false;
				boolean etaFound = false;
				Map<String, String> etaOrEtdMap = new HashMap<String, String>();
				for (EventData eventData : eventDataList) {
					String date = eventData.getEventData();
					if (!(date != null && !date.trim().equals("") && ("E034"
							.equals(eventData.getEventId())
							|| "E310".equals(eventData.getEventId())
							|| "E280".equals(eventData.getEventId())
							|| "E025".equals(eventData.getEventId())
							|| "E266".equals(eventData.getEventId()) || "E306"
								.equals(eventData.getEventId())))) {
						date = "";
					}

					etaOrEtdMap.put(eventData.getEventId(), date);

					/*
					 * if ("E310".equals(eventData.getEventId())) {
					 * eventDetailsBean.setEtdOrEtaPort(port);
					 * eventDetailsBean.setEtdOrEta("ETA");
					 * eventDetailsBean.setEtdOrEtaDate(eventData.getEventData()
					 * ); etaFound = true; etdOrETaFound = true; // break;
					 * 
					 * }
					 * 
					 * else if (etaFound &&
					 * "E034".equals(eventData.getEventId())) { continue; //
					 * break;
					 * 
					 * }
					 * 
					 * else if (!etaFound &&
					 * "E034".equals(eventData.getEventId())) {
					 * eventDetailsBean.setEtdOrEtaPort(port);
					 * eventDetailsBean.setEtdOrEta("ETD");
					 * eventDetailsBean.setEtdOrEtaDate(eventData.getEventData()
					 * ); etdOrETaFound = true; // break;
					 * 
					 * }
					 * 
					 * 
					 * else if ("E280".equals(eventData.getEventId())) {
					 * eventDetailsBean.setEtdOrEtaPort("");
					 * eventDetailsBean.setEtdOrEta("");
					 * eventDetailsBean.setEtdOrEtaDate(""); etdOrETaFound =
					 * false; } else if ("E025".equals(eventData.getEventId()))
					 * { eventDetailsBean.setEtdOrEtaPort("");
					 * eventDetailsBean.setEtdOrEta("");
					 * eventDetailsBean.setEtdOrEtaDate(""); etdOrETaFound =
					 * false; }
					 */
				}
				if (etaOrEtdMap.containsKey("E280") && etaOrEtdMap.containsKey("E025")) {
					continue;
				}

				else if (etaOrEtdMap.containsKey("E310") && !(etaOrEtdMap.containsKey("E280"))) {
					eventDetailsBean.setEtdOrEtaPort(port);
					eventDetailsBean.setEtdOrEta("ETA");
					eventDetailsBean.setEtdOrEtaDate(etaOrEtdMap.get("E310"));
					break;
				} else if (etaOrEtdMap.containsKey("E034") && !(etaOrEtdMap.containsKey("E025"))) {
					eventDetailsBean.setEtdOrEtaPort(port);
					eventDetailsBean.setEtdOrEta("ETD");
					eventDetailsBean.setEtdOrEtaDate(etaOrEtdMap.get("E034"));
					break;
				}
			}

		} catch (Exception e) {
			logger.error("Exception caught in fetchBigScreenData() of EvdAction in EVD " + e.getMessage());
			throw new Exception(e);
		} finally {
			connUtil.closeAll(con, null, stm, events_rs);
		}

		logger.info("Exiting fetchBigScreenData() of EvdAction in EVD");

		return eventDetailsBean;
	}

	/*
	 * public String getCountryPortViaShipId(String shipId, String eventType) {
	 * String location = StringUtils.EMPTY; String portName = StringUtils.EMPTY;
	 * String country = StringUtils.EMPTY; String port = StringUtils.EMPTY;
	 * String countryName = StringUtils.EMPTY; PreparedStatement ps_country =
	 * null, ps_port = null; ResultSet rs_country = null, rs_port = null;
	 * Connection conn = null;
	 * 
	 * try { String sql_country = null, sql_port = null; conn = getConnection();
	 * String fromCountry = StringUtils.EMPTY; String toCountry =
	 * StringUtils.EMPTY; int index_country = 0, index_port = 0;
	 * 
	 * if ("E278".equalsIgnoreCase(eventType)) { sql_country =
	 * "SELECT b.countryname from events_country a,country_loc b  where a.event_countryid=b.countryid and a.shipmenteventid='"
	 * + shipId + "' order by locationOrder asc"; sql_port =
	 * "SELECT b.portname from events_port a,port_loc b  where a.event_portid=b.portid and a.shipmenteventid='"
	 * + shipId + "' order by locationOrder asc"; } else { sql_country =
	 * "SELECT b.countryname from events_country a,country_loc b  where a.event_countryid=b.countryid and a.shipmenteventid='"
	 * + shipId + "'"; sql_port =
	 * "SELECT b.portname from events_port a,port_loc b  where a.event_portid=b.portid and a.shipmenteventid='"
	 * + shipId + "'"; } try { ps_country = conn.prepareStatement(sql_country);
	 * rs_country = ps_country.executeQuery(sql_country); while
	 * (rs_country.next()) { countryName =
	 * rs_country.getString("b.countryname"); if
	 * ("E278".equalsIgnoreCase(eventType)) { if (index_country == 0) {
	 * fromCountry = countryName; index_country++; } else { toCountry =
	 * countryName; } } else { if (index_country == 0) { country = countryName;
	 * } else { country += "," + countryName; } index_country++; } } } catch
	 * (SQLException e) { logger.error(
	 * "Exception caught in getCountryPortViaShipId() of BigScreenAction in EVD "
	 * +e.getMessage()); } finally { connUtil.closeAll(null, null, ps_country,
	 * rs_country); }
	 * 
	 * try { ps_port = conn.prepareStatement(sql_port); rs_port =
	 * ps_port.executeQuery(sql_port); while (rs_port.next()) { portName =
	 * rs_port.getString("b.portname"); if (index_port == 0) { port = portName;
	 * } else { port += "," + portName; } index_port++; } } catch (SQLException
	 * e) { logger.error(
	 * "Exception caught in getCountryPortViaShipId() of BigScreenAction in EVD "
	 * +e.getMessage()); } finally { connUtil.closeAll(null, null, ps_port,
	 * rs_port); }
	 * 
	 * if ("E278".equalsIgnoreCase(eventType)) { location = fromCountry + "[" +
	 * port + "]" + toCountry; } else {
	 * 
	 * if (!"".equalsIgnoreCase(country) && !"".equalsIgnoreCase(port)) {
	 * location = country + "(" + port + ")"; } else if
	 * (!"".equalsIgnoreCase(country) && ("".equalsIgnoreCase(port))) { location
	 * = country; } else if (!"".equalsIgnoreCase(port) &&
	 * ("".equalsIgnoreCase(country))) { location = port; } else if
	 * ("".equalsIgnoreCase(country) && "".equalsIgnoreCase(port)) { location =
	 * StringUtils.EMPTY; } }
	 * 
	 * } catch (Exception e) { logger.error(
	 * "Exception caught in getCountryPortViaShipId() of BigScreenAction in EVD "
	 * +e.getMessage()); } finally { connUtil.closeAll(conn, null, null, null);
	 * }
	 * 
	 * return location; }
	 */

	/*
	 * private String getEventNameId(String event, String type) { String events
	 * = StringUtils.EMPTY; String sql = StringUtils.EMPTY; PreparedStatement ps
	 * = null; ResultSet rs = null; Connection connObj = null; try { connObj =
	 * connUtil.getConnection(); if (type.equalsIgnoreCase("Name")) { sql =
	 * "select eventname from sip_foundation.event_type where eventId='" + event
	 * + "'"; } else if (type.equalsIgnoreCase("Id")) { sql =
	 * "select eventid from sip_foundation.event_type where eventId='" + event +
	 * "'"; } ps = connObj.prepareStatement(sql); rs = ps.executeQuery();
	 * 
	 * if (rs.next()) { if (type.equalsIgnoreCase("Name")) { events =
	 * rs.getString("eventname"); } else if (type.equalsIgnoreCase("Id")) {
	 * events = rs.getString("eventId"); }
	 * 
	 * }
	 * 
	 * } catch (SQLException e) { logger.error(
	 * "Exception caught in getEventNameId() of BigScreenAction in EVD "
	 * +e.getMessage()); } finally { connUtil.closeAll(connObj, null, ps, rs); }
	 * return events; }
	 */

	public EventDetails getEventDetails(String eventId, String trackingId, String portId) {

		logger.info("Entering getEventDetails() of EvdAction in EVD");
		
		Connection connection = null;
		PreparedStatement selectStmtEventDetails = null;
		String sqlsEventDetails = null;
		ResultSet rsEventDetails = null;
		EventDetails eventDetails = new EventDetails();
		String shipmenteventid = null, countryList = null, route = null;
		PreparedStatement selectStmtE = null;
		ResultSet rsEventDe = null;
		String portIdStr = "";
		
		sqlsEventDetails = "select * from sip_foundation.event_details a,sip_foundation.events_country d, sip_foundation.events_port f "
				+ "where a.shipmenteventid=d.ShipmentEventId and a.shipmenteventid=f.ShipmentEventId and a.trackingId ='"
				+ trackingId + "' and a.eventId='" + eventId + "'";
		try {
			connection = getConnection();
			selectStmtE = connection.prepareStatement(sqlsEventDetails);

			rsEventDe = selectStmtE.executeQuery();
			while (rsEventDe.next()) {
				shipmenteventid = rsEventDe.getString("a.shipmenteventid");
			}
		} catch (SQLException e) {
			logger.error("Exception caught in getEventDetails() of EvdAction in EVD " + e.getMessage());
		} finally {
			connUtil.closeAll(connection, null, selectStmtE, rsEventDe);
		}

		if(portId !=null && portId.trim().length() > 0)
			portIdStr = " and a.portId='" + portId + "'";
		
		if (null == shipmenteventid) {
			sqlsEventDetails = "select distinct a.shipmenteventid, "
					                         + "a.soeId,"
					                         + "g.Name,"
					                         + "b.EventDesc,"
					                         + "a.eventId,"
					                         + "DATE_FORMAT(a.CREATIONDATETIME,'%Y-%m-%d %H:%i') as CREATIONDATETIME,"
					                         + "if(a.EventDataType = 'Date and Time', DATE_FORMAT(a.data,'%Y-%m-%d %H:%i') , a.data) as data,"
					                         + "a.countryId,"
					                         + "a.portId,"
					                         + "a.trackingId,"
					                         + "c.containerNo,"
					                         + "DATE_FORMAT(a.pubDateTime,'%Y-%m-%d %H:%i') as pubDateTime,"
					                         + "b.eventName,"
					                         + "a.CargoType,"
					                         + "a.originatorId,"
					                         + "a.GPSCoordinates,"
					                         + "a.location,"
					                         + "a.EventDataType,"
					                         + "a.DocumentType,"
					                         + "a.DocumentHashKey,"
					                         + "a.DocumentPublicKey,"
					                         + "a.DocumentURI,"
					                         + "a.LocationType,"
					                         + "a.OriginatorName,"
					                         + "(SELECT"
					                         + "   CASE"
					                         + "     WHEN a.EVENTID = 'E278' THEN "
					                         + "        (SELECT GROUP_CONCAT(cl.countryname separator '~') from events_country ec,country_loc cl where ec.event_countryid=cl.countryid and ec.shipmenteventid=a.SHIPMENTEVENTID order by ec.locationOrder asc)"
					                         + "     ELSE"
					                         + "        (SELECT GROUP_CONCAT(cl.countryname separator '~') from events_country ec,country_loc cl where ec.event_countryid=cl.countryid and ec.shipmenteventid=a.SHIPMENTEVENTID)"
					                         + "     END"
					                         + ") AS countryname, "
					             			 +"(SELECT"
					             			 +"	  CASE"
					             			 +"		WHEN a.EVENTID = 'E278' THEN"
					             			 +"		   (SELECT GROUP_CONCAT(pl.portname separator '~') from events_port ep,port_loc pl where ep.event_portid=pl.portid and ep.shipmenteventid=a.SHIPMENTEVENTID order by locationOrder asc) "
					             			 +"		ELSE"
					             			 +"		   (SELECT GROUP_CONCAT(pl.portname separator '~') from events_port ep,port_loc pl where ep.event_portid=pl.portid and ep.shipmenteventid=a.SHIPMENTEVENTID) "
					             			 +"     END"
					             			 +") AS portname "
					                         + "from sip_foundation.event_details a,sip_foundation.events_container c, sip_foundation.soe_details g, sip_foundation.event_type b "
					                         + "where a.shipmenteventid=c.ShipmentEventId and a.eventId=b.eventId and a.trackingId ='"+ trackingId+"'"+" and a.soeId=g.SOEID and a.eventId='" + eventId + "'" + portIdStr;
		} else {
			sqlsEventDetails = "SELECT distinct a.shipmenteventid,"
					                         + "a.soeId,"
					                         + "g.Name,"
					                         + "b.EventDesc,"
					                         + "a.eventId,"
					                         + "DATE_FORMAT(a.CREATIONDATETIME,'%Y-%m-%d %H:%i') as CREATIONDATETIME,"
					                         + "if(a.EventDataType = 'Date and Time', DATE_FORMAT(a.data,'%Y-%m-%d %H:%i') , a.data) as data,"
					                         + "a.countryId,"
					                         + "a.portId,"
					                         + "a.trackingId,"
					                         + "c.containerNo,"
					                         + "DATE_FORMAT(a.pubDateTime,'%Y-%m-%d %H:%i') as pubDateTime,"
					                         + "b.eventName,"
					                         + "a.CargoType,"
					                         + "a.originatorId,"
					                         + "a.GPSCoordinates,"
					                         + "a.location,"
					                         + "a.EventDataType,"
					                         + "a.DocumentType,"
					                         + "a.DocumentHashKey,"
					                         + "a.DocumentPublicKey,"
					                         + "a.DocumentURI,"
					                         + "a.LocationType,"
					                         + "a.OriginatorName,"
					                         + "(SELECT"
					                         + "   CASE"
					                         + "     WHEN a.EVENTID = 'E278' THEN "
					                         + "        (SELECT GROUP_CONCAT(cl.countryname separator '~') from events_country ec,country_loc cl where ec.event_countryid=cl.countryid and ec.shipmenteventid=a.SHIPMENTEVENTID order by ec.locationOrder asc)"
					                         + "     ELSE"
					                         + "        (SELECT GROUP_CONCAT(cl.countryname separator '~') from events_country ec,country_loc cl where ec.event_countryid=cl.countryid and ec.shipmenteventid=a.SHIPMENTEVENTID)"
					                         + "     END"
					                         + ") AS countryname, "
					             			 +"(SELECT"
					             			 +"	  CASE"
					             			 +"		WHEN a.EVENTID = 'E278' THEN"
					             			 +"		   (SELECT GROUP_CONCAT(pl.portname separator '~') from events_port ep,port_loc pl where ep.event_portid=pl.portid and ep.shipmenteventid=a.SHIPMENTEVENTID order by locationOrder asc) "
					             			 +"		ELSE"
					             			 +"		   (SELECT GROUP_CONCAT(pl.portname separator '~') from events_port ep,port_loc pl where ep.event_portid=pl.portid and ep.shipmenteventid=a.SHIPMENTEVENTID) "
					             			 +"     END"
					             			 +") AS portname "					                         
					                         + "FROM sip_foundation.event_details a, sip_foundation.event_type b, sip_foundation.events_container c, sip_foundation.events_country d, sip_foundation.events_port f, sip_foundation.soe_details g "
					                         + "where a.eventId=b.eventId and a.shipmenteventid=c.ShipmentEventId "
					                         + "and a.shipmenteventid=d.ShipmentEventId and a.soeId=g.SOEID and a.shipmenteventid=f.ShipmentEventId and a.trackingId ='"+trackingId+"' and a.eventid='"+eventId+"'" + portIdStr;
		}
		logger.info("sqlsEventDetails:" + sqlsEventDetails);

		try {
			connection = getConnection();
			selectStmtEventDetails = connection.prepareStatement(sqlsEventDetails);
			rsEventDetails = selectStmtEventDetails.executeQuery();
			while (rsEventDetails.next()) {
				shipmenteventid = rsEventDetails.getString("a.shipmenteventid");
				countryList = rsEventDetails.getString("countryname");
				route = rsEventDetails.getString("portname");
				eventDetails.setContainerNo(rsEventDetails.getString("c.containerNo"));
				eventDetails.setTrackingId(rsEventDetails.getString("a.trackingId"));
				eventDetails.setEventDesc(rsEventDetails.getString("b.EventDesc"));
				eventDetails.setContainerType("40ft High Cube Reefer");
				eventDetails.setPortId(rsEventDetails.getString("a.portId"));
				eventDetails.setCargoType(rsEventDetails.getString("a.CargoType"));
				eventDetails.setVGM("2600");
				eventDetails.setCargoWeight("2600");
				eventDetails.setGPSCoordinates(rsEventDetails.getString("a.GPSCoordinates"));
				eventDetails.setEventId(rsEventDetails.getString("a.eventId"));
				eventDetails.setEventName(rsEventDetails.getString("b.eventName"));
				eventDetails.setDocumentType(rsEventDetails.getString("a.DocumentType"));
				eventDetails.setEventDataType(rsEventDetails.getString("a.EventDataType"));
				if (eventDetails.getEventDataType().equals("BoL no")) {
					eventDetails.setBolNumber(rsEventDetails.getString("data"));
				}
				// eventDetails.setEventDataType(eventDataType);
				eventDetails.setEventData(rsEventDetails.getString("data"));
				eventDetails.setLocationType(rsEventDetails.getString("a.LocationType"));
				eventDetails.setEventDateTime(rsEventDetails.getString("pubDateTime"));
				eventDetails.setEventReportedTime(rsEventDetails.getString("CREATIONDATETIME"));
				eventDetails.setSoeId(rsEventDetails.getString("a.soeId"));
				eventDetails.setSoeName(rsEventDetails.getString("g.Name"));
				eventDetails.setOriginatorName(rsEventDetails.getString("a.OriginatorName"));
				eventDetails.setOriginatorId(rsEventDetails.getString("a.originatorId"));
				eventDetails.setImoNumber(rsEventDetails.getString("a.CargoType"));
				eventDetails.setVoyageNumber(rsEventDetails.getString("a.CargoType"));
				String documentURI = rsEventDetails.getString("a.DocumentURI");
				if (documentURI != null && documentURI.contains("?dl=")) {
					documentURI = documentURI.substring(0, documentURI.indexOf("?dl=")) + "?raw=1";
					eventDetails.setDocumentURI(documentURI);
				}
			}

			// String routeLocation = getCountryPortViaShipId(shipmenteventid,eventId);
			if ("E278".equalsIgnoreCase(eventId)) {
				if (countryList != null) {
					String ss[] = countryList.split("~");
					String fromCountry = ss[0];
					String toCountry = ss[1];
					eventDetails.setFromCountry(fromCountry);
					eventDetails.setToCountry(toCountry);
				}
				if (route != null)
					eventDetails.setRouteList(new ArrayList<String>(Arrays.asList(route.split("~"))));
			}else{
				if (countryList != null)
					eventDetails.setCountryName(countryList);
				if (route != null){
					eventDetails.setRouteList(new ArrayList<String>(Arrays.asList(route.split("~"))));
					if(route.split("~").length == 1){
						String ss[] = route.split("-");
						if(ss.length > 1){
						  String portDtls = ss[1] + " (" + ss[0] + ")";
						  eventDetails.setPortDtls(portDtls);
						}
					}
				}
			}
			
			/*
			 * if ("E278".equalsIgnoreCase(eventId)) { // standard format is
			 * fromCountry(route)toCountry as defined // in
			 * getCountryPortViaShipId // route can be a single port or comma
			 * separated ports // split location like Kenya(OMSLV-Salalah)United
			 * States if (routeLocation.contains("(") &&
			 * routeLocation.contains(")")) { String ss[] =
			 * routeLocation.split("\\("); String fromCountry = ss[0]; String
			 * fc[] = ss[1].split("\\)"); String toCountry = fc[1]; String route
			 * = fc[0]; eventDetails.setFromCountry(fromCountry);
			 * eventDetails.setToCountry(toCountry);
			 * 
			 * eventDetails.setRouteList(new
			 * ArrayList<String>(Arrays.asList(route.split(",")))); } }
			 */
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			logger.error("Exception caught in getEventDetails() of EvdAction in EVD " + sqle.getMessage());
		} finally {
			connUtil.closeAll(connection, null, selectStmtEventDetails, rsEventDetails);
		}
		logger.info("Exiting getEventDetails() of EvdAction in EVD");
		return eventDetails;
	}

	public String eventDetailsAction() {

		String eventId = this.getEventId();
		String trackingId = this.getTrackingId();
		String portId = this.getPortId();
		EventDetails eventDetails = getEventDetails(eventId, trackingId, portId);
		eventDetailsobj = eventDetails;

		return "SUCCESS";
	}

}
