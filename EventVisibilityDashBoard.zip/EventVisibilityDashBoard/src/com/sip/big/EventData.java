package com.sip.big;

public class EventData {
	public String eventId;
	public String eventData;
	public String creationDateTime;
	public String originatorName;
	public String eventName;
	public String eventDataType;
	public String portId;
	public String documentURI;
	public String documenType;

	public String getOriginatorName() {
		return originatorName;
	}

	public void setOriginatorName(String originatorName) {
		this.originatorName = originatorName;
	}

	public String getCreationDateTime() {
		return creationDateTime;
	}

	public void setCreationDateTime(String creationDateTime) {
		this.creationDateTime = creationDateTime;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public String getEventData() {
		return eventData;
	}

	public void setEventData(String eventData) {
		this.eventData = eventData;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getEventDataType() {
		return eventDataType;
	}

	public void setEventDataType(String eventDataType) {
		this.eventDataType = eventDataType;
	}

	public String getPortId() {
		return portId;
	}

	public void setPortId(String portId) {
		this.portId = portId;
	}

	public String getDocumentURI() {
		return documentURI;
	}

	public void setDocumentURI(String documentURI) {
		this.documentURI = documentURI;
	}

	public String getDocumenType() {
		return documenType;
	}

	public void setDocumenType(String documenType) {
		this.documenType = documenType;
	}

}
